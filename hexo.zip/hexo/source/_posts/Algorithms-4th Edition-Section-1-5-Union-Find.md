title: "Algorithms, 4th Edition. Section 1.5: Union-Find"
date: 2015-12-13 14:02:05
tag: [Algorithms, Robert Sedgewick]
categories: Algorithms
---
前言
---
数学是科学的皇后，算法是计算机科学的明珠。因为算法基础比较薄弱，选择图文并茂、形象直观的《算法4》作为入门，优先理解数据结构，熟悉以后再刷《算法导论》。
<!--more-->
>* 语言：Java
>* 教材：[Algorithms, 4th Edition](http://book.douban.com/subject/4854123/)， [英文讲义](http://algs4.cs.princeton.edu/15uf/)

***
先说说读了前几章的感受
---
Robert Sedgewick的《算法4》对新手友好，不会上来就一大堆证明，有大量的图来让你明白例如：排序，查找，树和图的算法运行过程。[Introduction to Algorithms, 3rd Edition](http://book.douban.com/subject/20432061/)相对而言，偏重算法分析，而且是坑爹的Pascal语言，不适合小白。
不过，《算法4》也有缺点，目前来说，第一章主要介绍Java背景和编程思想，我看下来感觉比较繁琐。就我个人来说，对Java不懂的话，可以这么做：直接花10分钟看《[Head First Java](http://book.douban.com/subject/2000732/)》，再花1小时看《[Core Java](http://-book.douban.com/subject/25762168/)》第一册（不看7-9章图形编程），对Java就能有大概印象了，学习算法绰绰有余。之后就应该看《[Thinking in Java](http://book.douban.com/subject/2130190/)》和《[Effective Java](http://book.douban.com/subject/3360807/)》了。

>因为我算法基础薄弱，第一章的内容就看得不是很懂，这篇笔记写的过程中，参考了很多dm_vincent大神的思考。

***
本文内容
---

第一章最后是一个Case Study，介绍了Union-Find：一种解决**动态连通性**问题的算法。

动态连通性问题，在生活中非常常见：
* 比如**大型实验室中的两台计算机进行连接**，我们需要判断是否需要架设一条新的网线。
* 对于已经连通的，我们忽略请求；未连通的，我们需要架设新的网线。

***
模型数字化示意
---
![dynamic-connectivity-tiny](http://algs4.cs.princeton.edu/15uf/images/dynamic-connectivity-tiny.png)
如上图，从上往下看：
1. 通过依次输入一组组“整数对”（pairs），即上图中的（4,3），（3,8）等等，来表达网络连接的需求申请。
2. 使用程序判断“需求申请”，先查看是否连通，再考虑是否需要架线。
3. 因此，可以忽略已经处于连通状态的节点对，比如上图中第六个输入的（8,9），输入之后表示为灰色。
4. 随着数据的不断输入，整个图的连通性也在不断发生变化。
5. 这里是对“问题”的直观感受，不必太细究。


***
程序策略&具体建模
---
为这个算法设计的API如图所示。方法还没有确定，但是先不着急解决问题。
![uf-api](http://algs4.cs.princeton.edu/15uf/images/uf-api.png)
***
接着我们来进行模型的简化：
***
本问题的难点在于连通的定义，比较好的方式如下。
* 对于连通的所有节点，我们可以认为它们属于一个组。反之，若两个节点属于不同组,那么它们是不连通的。
* 按照上面的假设，**“判断输入的两个节点是否连通”**这个问题简化为**“判断它们是否是相同的组”**。
***
>具体实现：
1. 为简单起见，我们将所有的节点用整数表示，即用“0”到“N-1”的整数表示这N个节点。（需要使用其他的数据类型表示节点时，比如使用字符串，那么可以用哈希表来进行映射，即将String映射成这里需要的Integer类型。）
2. 使用数组来表示这一层关系，考虑到组号可变，用数值的值（value）表示节点的组号，数组的地址编号（index）表示节点的实际名字。
3. 例如，“0号节点”的组号定义为0，id[0]=0。左边的0是节点名字，不可变；右边的0为节点组号，可变。
4. 需要注意的是，在第一次申请连通要求之前，每个节点必然都是孤立的，即他们分属于不同的组。

该数组可以初始化为：
```
{
    count=N;                         #总的节点数N 
    id=new int[N];                   #定义数据类型为int，长度为N的，名字为id的数值 
    for(int i = 0; i < N; i++)       #给每个节点编号
    id[i] = i;
}
```

目前为止最直观的API方法是这样的
***
>1.查询节点属于的组（find）

数组对应位置的值即为组号。

>2.判断两个节点是否属于同一个组（connected）

分别得到两个节点的组号，然后判断组号是否相等。

>3.连接两个节点，使之属于同一个组（union）

分别得到两个节点的组号，组号相同时操作结束，不同时，将其中的一个节点的组号换成另一个节点的组号。

>4.获取组的数目（count）

初始化为节点的数目，然后每次成功连接两个节点之后，递减1。

***
这就是我们的第一个算法
***
1. Quick-find
---
```
public class UF
{
	private int[] id; 
	private int count;
	public UF(int N)
	{
		count = N;
		id = new int[N]; 
		for (int i = 0; i < N; i++)              #数组初始化
		id[i] = i;
	}

	public int count()                               #设定count，find，union，connected方法
	{return count；}

	public boolean connected(int p, int q)
	{return find(p) == find(q);}

	public int find(int p)
	{ return id[p]; }

	public void union(int p, int q)
	{ 
		int pID = find(p);
		int qID = find(q);
		if (pID == qID) return;                    #如果两个组号相等，直接返回 
		for (int i = 0; i < id.length; i++)
			if (id[i] == pID) id[i] = qID;     #不等。遍历一次，使所有p组号的电脑，改变组号为q。 
		count--;                                   #每合并一次，组数-1
	}

	public static void main(String[] args)
	{ 
		int N = StdIn.readInt();                    #标准输入，这个库需要从官网下载
		UF uf = new UF(N); 
		while (!StdIn.isEmpty())
		{
			int p = StdIn.readInt();
			int q = StdIn.readInt(); 
			if (uf.connected(p, q)) continue;   #continue的意思是，如果p.q连通（逻辑“是”），那么跳过下面语句，从头开始进入下一循环。（忽略连通pairs）
			uf.union(p, q);                     #进行union操作，使它们组号相同
			StdOut.println(p + " " + q);        #输出需要连接的pairs
		}
		StdOut.println(uf.count() + " components"); #输出
	}
}
```

下面是Quick-find的图示
![Quick-find](http://algs4.cs.princeton.edu/15uf/images/quick-find-overview.png)

>1.输入的pairs是(5， 9)
2.判断：通过find方法发现它们的组号并不相同。如果相同，系统就不操作了。
3.然后在union的时候通过一次遍历，将组号1的所有电脑都改成8。（由8改成1也是可以的，任取一种）
***
上述代码的find方法非常快，因为仅仅需要一次数组读取操作就能够找到该节点的组号。

>但是问题在于union：
* 添加新网线就意味着“组号的修改”。因为不能确定哪些节点的组号需要被修改，因此需要对整个数组进行遍历，找到需要修改的节点，逐一修改。这是N次的访问数组，效率非常低。
* 如果添加新网线的数量是N-1，节点数量是N，那么最后的时间复杂度就是N^2-N，平方阶复杂度。

对于大规模的数据而言，平方阶的算法是存在问题的。为了解决这个问题，能做的就是提高union方法的效率，让它不再需要遍历整个数组。
***
2. Quick-union
---
考虑一下，为什么以上的解法复杂度如此之高？因为每个节点所属的组号都是单独记录，没有更好的方式组织起来；当涉及到修改的时候，除了逐一通知、修改，别无他法。
所以现在的问题就变成了，如何将节点以更好的方式组织起来？
组织的方式有很多种，但是最直观的还是将组号相同的节点组织在一起。想想所学的数据结构，什么样子的数据结构能够将一些节点给组织起来？常见的就是链表，图，树这些了。
但是哪种结构对于查找和修改的效率最高？毫无疑问是树，因此考虑如何将节点和组的关系以树的形式表现出来。
***
如果不改变底层数据结构，即不改变使用数组的表示方法的话。可以采用parent-link的方式将节点组织起来。

>* 举例而言，1节点（id[1]）的值为“5”，“5”就是1节点的父节点的名字；接着5节点来寻找它的父节点，id[5]=7，为7节点……
* 经过若干次查找，一个节点总是能够找到它的根节点，即满足id[root] = root。这样的节点也就是组的根节点了，使用根节点的组号来表示整根树枝的组号。

所以在处理一个pair的时候，首先需要找到pair中每一个节点的组号(即它们所在树的根节点的名字)。
如果属于不同的组的话，就将其中一个根节点的父节点设置为另外一个根节点，相当于将一颗独立的树“变成”另一颗独立的树的子树。
***
直观的过程如下图所示。
![Quick-union](http://algs4.cs.princeton.edu/15uf/images/quick-union-overview.png)

在实现上，和之前的Quick-Find只有find和union两个方法有所不同：
```
private int find(int p)
{
	while (p != id[p]) p = id[p];   #找到树根
	return p;
}
public void union(int p, int q)
{
	int pRoot = find(p);           #union通过“树根赋值”实现
	int qRoot = find(q);
	if (pRoot == qRoot) return;
	id[pRoot] = qRoot;
	count--;
}
```
***
3. Weighted quick-union
---
但是这个时候又引入了新的问题：
树这种数据结构容易出现极端情况。
因为在建树的过程中，树的最终形态严重依赖于输入数据本身的性质，比如数据是否排序，是否随机分布等等。
比如在输入数据是有序的情况下，构造的二叉搜索树（BST）会退化成一个链表。在我们这个问题中，也是会出现的极端情况的，如下图所示。
![Quick-union 	Worst](/images/1-5-1.png)


为了克服这个问题，二叉搜索树（BST）可以演变成为红黑树或者AVL树等等。
然而，在我们考虑的这个应用场景中，每对节点之间是不具备可比性的。
因此需要想其它的办法。在没有什么思路的时候，多看看相应的代码可能会有一些启发，考虑一下Quick-Union算法中的union方法实现：
```
public void union(int p, int q)
{
        // Give p and q the same root.  
        int pRoot = find(p);  
        int qRoot = find(q);  
        if (pRoot == qRoot)   
            return;  
        id[pRoot] = qRoot;  // 将一颗树(即一个组)变成另外一课树(即一个组)的子树  
        count--;  
}
```
上面 id[pRoot] = qRoot 这行代码看上去似乎不太对劲。p所在的树总是会被作为q所在树的子树，从而实现两颗独立的树的融合。
那么这样的约定是不是总是合理的呢？
显然不是，比如p所在的树的规模比q所在的树的规模大的多时，p和q结合之后形成的树就是十分不和谐的一头轻一头重的”畸形树“了。

所以我们应该考虑树的大小，然后再来决定到底是调用“id[pRoot] = qRoot”或者是“id[qRoot] = pRoot”。
尽量用size小的树作为子树和size大的树进行合并。这样就能够尽量的保持整棵树的平衡。
***
所以现在的问题就变成了：树的大小该如何确定？
***
我们回到最初的情形，即每个节点最一开始都是属于一个独立的组，通过下面的代码进行初始化：
```
for (int i = 0; i < N; i++)
id[i] = i;    // 每个节点的组号就是该节点的序号
```
以此类推，在初始情况下，每个组的大小都是1，因为只含有一个节点，所以我们可以使用额外的一个数组来维护每个组的大小，对该数组的初始化也很直观：
```
for (int i = 0; i < N; i++)
        sz[i] = 1;    // 初始情况下，每个组的大小都是1
```
而在进行合并的时候，会首先判断待合并的两棵树的大小，然后按照上面图中的思想进行合并，实现代码：
``` 
public void union(int p, int q)
{
        int i = find(p);  
        int j = find(q);  
        if (i == j) return;     
	if (sz[i] < sz[j]) { id[i] = j; sz[j] += sz[i]; }   #将小树作为大树的子树 
	else               { id[j] = i; sz[i] += sz[j]; }
        count--;  
}
```
***
Quick-Union 和 Weighted Quick-Union 的比较：
![Weighted quick-union](/images/1-5-2.png)

可以发现，通过sz数组决定如何对两棵树进行合并之后，最后得到的树的高度大幅度减小了。这是十分有意义的，因为在Quick-Union算法中的任何操作，都不可避免的需要调用find方法，而该方法的执行效率依赖于树的高度。树的高度减小了，find方法的效率就增加了，从而也就增加了整个Quick-Union算法的效率。

上图其实还可以给我们一些启示，即对于Quick-Union算法而言，节点组织的理想情况应该是一颗十分扁平的树，所有的孩子节点应该都在height为1的地方，即所有的孩子都直接连接到根节点。这样的组织结构能够保证find操作的最高效率。
***
那么如何构造这种理想结构呢？
***
在find方法的执行过程中，不是需要进行一个while循环找到根节点嘛？
如果保存所有路过的中间节点到一个数组中，然后在while循环结束之后，将这些中间节点的父节点指向根节点，不就行了么？
但是这个方法也有问题，因为find操作的频繁性，会造成频繁生成中间节点数组，相应的分配销毁的时间自然就上升了。
***
那么有没有更好的方法呢？
***
还是有的，即将节点的父节点指向该节点的爷爷节点，这一点很巧妙，十分方便且有效。
相当于在寻找根节点的同时，对路径进行了压缩，使整个树结构扁平化。
相应的实现如下，实际上只需要添加一行代码：
```
private int find(int p)
{
	while (p != id[p])
        {  
            id[p] = id[id[p]];    #将p节点的父节点设置为它的爷爷节点  
            p = id[p];  
        }  
        return p;  
}
```
***
至此，动态连通性相关的Union-Find算法基本上就介绍完了.
从容易想到的Quick-Find,到相对复杂但更加高效的Quick-Union，然后到对Quick-Union的几项改进，算法的效率不断的提高。
***
这几种算法的时间复杂度如下所示：
![uf-performance](http://algs4.cs.princeton.edu/15uf/images/uf-performance.png)

***
总结
---
1.对大规模数据进行处理，使用平方阶的算法是不合适的，比如简单直观的Quick-Find算法。
2.通过发现问题的更多特点，找到合适的数据结构，然后有针对性的进行改进，得到了Quick-Union算法及其多种改进算法，最终使得算法的复杂度降低到了近乎线性复杂度。
3.如果需要的功能不仅仅是检测两个节点是否连通，还需要在连通时得到具体的路径，那么就需要用到别的算法了，比如DFS或者BFS。
