title: 在Ubuntu上搭建Hexo静态页面博客，并部署到Github
date: 2015-12-12 02:35:16
tag: [Hexo, Ubuntu, Nodejs]
categories: Hexo
---
前言
---
原计划是用wordpress搭建生活博客的，但是总感觉太臃肿了。在知乎上搜了一圈，被Hexo的清新界面打动了，再加上GitHub Pages提供免费服务，有了兴趣自己从头到尾操作一遍。
<!--more-->
>* 系统环境：Ubuntu 14.04 LTS 64-bit
>* 安装内容：Git、GitHub Pages、SSH KEYS、Nodejs、Hexo

***
安装 git客户端
---
Ubuntu对git很友好，安装很方便。按Ctrl + Alt + T 打开终端，输入如下命令，即可完成安装：
```
$ sudo apt-get install git
$ sudo apt-get install git-core
```

申请GitHub Pages
---
1. 首先注册一个[GitHub](https://github.com/ "github")帐号，已有请忽略
2. 完成后，点右上角的加号，点击“New repository”
3. 跳转后，在“Repository name”下方填写博客地址：
username.github.io 
4. 打钩“Initialize this repository with a README” 
5. 点“创建”，完成。

生成 SSH keys
---
Hexo部署到Github需要SSH keys，因此需要提前准备好。
1. 先检测本机是否已有，终端中输入： 
```
$ ls -al ~/.ssh 
```
2. 如果有SSH keys，一般会看到如下文件 ：
```
id_rsa    id_rsa.pub
```
3. 如果没有的话，就生成一个SSH keys：
```
$ ssh-keygen -t rsa -C "XXX@XXX.com"   #“XXX”改为你自己的邮箱
```
4. 回车，提示：
```
 Generating public/private rsa key pair.                           #提示生成密钥配对
 Enter file in which to save the key (/Users/you/.ssh/id_rsa):      #这里是问你SSH keys要保存在哪里，一般不用改，直接回车
```
5. 继续回车，提示：
```
Enter passphrase (empty 'for' no passphrase):   #这是让你设定SSH的密码，这里可设可不设。
Enter same passphrase again: 
```
6. 接下来就会提示成功：
```
Your identification has been saved in /Users/you/.ssh/id_rsa.
Your public key has been saved in /Users/you/.ssh//id_rsa.pub.
The key fingerprint is:
01:0f:f4:3b:ca:85:d6:17:a1:7d:f0:68:9d:f0:a2:db XXX@XXX.com
```
***
本地准备完毕，需要把SSH keys提交到github
---
7. 默认情况下，运行下面的代码就可以把key复制到你的粘贴板中：
```
$ clip < ~/.ssh/id_rsa.pub
```
8. 然后在github界面中，右上角点击“Account settings”，弹出设定界面。左侧点击“SSH Keys”，“Add SSH key”，黏贴之前的key，提交。
9. 最后还需要进行一下检验：
```
$ ssh -T git@github.com
```
10. 回车，输入密码，提示：
```
Warning: Permanently added the RSA host key for IP address '1.1.1.0' to the list of known hosts.
Hi Alex! You've successfully authenticated， but GitHub does not provide shell access.
```
这就表明提交成功了。

***
安装Nodejs
---
Nodejs需要安装g++及libssl-dev环境，安装方法如下：
``` 
$ sudo apt-get install g++ 
$ sudo apt-get install libssl-dev
```
安装好之后，就可以下载安装Nodejs了。[Download | Node.js](https://nodejs.org/en/download/ "Download | Node.js")
[官方文档](https://hexo.io/zh-cn/docs/index.html)介绍的是nvm安装的方法。也可以参考我这里介绍的两种安装方式：
***
a. 编译好的文件
***
1. 下载页面中，选择“Linux Binaries (.tar.gz)”，“64-bit”
2. 下载完成后在 终端下输入：
```
$ cd ~/Downloads/                          #进入下载文件夹，看情况调整
$ tar zxvf node-v4.2.3-linux-x64.tar.gz    #解压
$ cd node-v4.2.3-linux-x64/bin 
$ ls -l                                    #这里就可以看到“node”以及“npm”了
$ ./node -v                                #查看安装是否完成
```
3. 因为是编译好的文件，需要设置全局（环境变量）：
```	
$ ln -s ~/Downloads/node-v4.2.3-linux-x64/bin/bin/node /usr/local/bin/node
$ ln -s ~/Downloads/node-v4.2.3-linux-x64/bin/bin/npm /usr/local/bin/npm
```
***
b.源代码安装
***
这种方法比较麻烦，编译需要几十分钟，所以不推荐
1. 点击“Source Code”，“node-v4.2.3.tar.gz”，下载源代码
2. 下载完成后在 终端下输入：
```
$ cd ~/Downloads/                #默认下载是保存在“～/Downloads”文件夹里，看情况调整
$ tar zxvf node-v4.2.3.tar.gz    #根据文件名调整
$ cd node-v4.2.3 
$ ./configure
$ sudo make                      #编译，并安装。
$ sudo make install
```
3. 安装好后，在 终端下输入：
```
$ node -v
v4.2.3
```
4. 即可看到安装好的Nodejs版本号

***
安装Hexo
---

1. 前面的步骤都完成后，就可以通过 npm 安装 hexo 了：
```
$ npm install -g hexo-cli
```
2. 国内有时候会被墙，出现404 error，可以尝试把官方源替换为 淘宝npm源，之后再执行安装Hexo：
```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```
3. npm安装完成后，进行初始化操作：
```
$ hexo init hexo      #初始化，创建一个名为 hexo 文件夹，存放博客文件
$ cd hexo             #进入 hexo 目录
$ npm install         #安装相关
```
4. 至此，本地安装 Hexo 完成。

其他配置请查阅官方文档: [https://hexo.io/zh-cn/docs/index.html](https://hexo.io/zh-cn/docs/index.html)



***
博客基本设置
---
现在我们要开始建设真正的博客了。
1. 在 终端下进入博客文件目录，然后调试：
```
$ cd ~/Downloads/node-v4.2.3/hexo  #进入博客文件目录
$ hexo g                           #生成第一个静态页面
$ hexo s                           #启动本地服务，进行文章预览调试 
```
2. 在浏览器里打开[http://0.0.0.0:4000/](http://0.0.0.0:4000/"本地预览")，即可进行本地预览调试。**每次变更设置后，都可以先用此命令调试。**

3. 常用命令
```
$ hexo new "文章名"             #新建文章
$ hexo new page "页面名"        #新建页面
$ hexo g                        #生成静态页面至public目录
$ hexo s                        #开启预览访问端口
$ hexo d                        #将.deploy目录部署到GitHub
$ hexo help                     #帮助
$ hexo version                  #版本
```

4. 主题
Hexo的主题都比较简洁，可以到官方下载：[https://hexo.io/themes/](https://hexo.io/themes/)
这里使用的是 Yilia 主题，安装教程见： [https://github.com/litten/hexo-theme-yilia](https://github.com/litten/hexo-theme-yilia)

5. 我们可以在主目录 **_config.yml**文件中修改大部份的配置：
```
# Site
title         #标题
subtitle      #副标题
description   #描述
author        #您的名字
language      #网站语言
timezone      #网站时区。Hexo预设使用您电脑的时区

# Extensions
## Plugins: http://hexo.io/plugins/
## Themes: http://hexo.io/themes/
theme: yilia  #主题配置
```
更多配置见[官方指南](https://hexo.io/zh-cn/docs/configuration.html)，按照自己的需求更改。

***
文档编辑
---
1. 使用之前的命令：
```
hexo new "文章名"
```
2. 会在“.\hexo\source\_posts”目录下生成一个markdown文件
```
文章名.md
```
3. Ubuntu原生支持读写md文件，但是需要markdown语法来编辑。写完后最好先进行本地预览调试。

Markdown语法学习：[http://ibruce.info/2013/11/26/markdown/](http://ibruce.info/2013/11/26/markdown/)


***
部署到Github
---
1. 部署到Github前，需要配置主目录下的_config.yml文件，找到以下内容，修改为：
```
# Deployment
## Docs: http://hexo.io/docs/deployment.html
## repo 地址可以在 github 进入你的库里面右下角的 SSH clone URL 复制过来。

deploy:
  type: git
  repository: git@github.com:XXX/XXX.github.io.git
  branch: master
  message:
```

2. 需要注意的是，到这里还需要安装一个插件（hexo-deployer-git）才能正常发布文章。
```
$ npm install hexo-deployer-git --save
```
3. 每次部署的步骤，可按以下三步来进行：
```
hexo clean      #清除缓存 网页正常情况下可以忽略此条命令
hexo generate
hexo deploy
```

4. 当部署完成后，在浏览器中打开(XXX.github.io)，正常显示网页，表明部署成功。

***
大功告成～^_^
---
